The humble, but powerful, URL runs everything around us. Chances
are you've used several just to read this text.

Hyperlink is a featureful, pure-Python implementation of the URL, with
an emphasis on correctness. BSD licensed.

See the docs at http://hyperlink.readthedocs.io.


